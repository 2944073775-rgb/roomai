const http = require('http');
const fs = require('fs');
const path = require('path');

// Store uploaded images temporarily
let uploadedImages = [];
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR);
}

const PORT = process.env.PORT || 3000;
const LAN_IP = process.env.LAN_IP || '0.0.0.0';

// MIME types
const mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.json': 'application/json'
};

// Parse multipart form data
function parseMultipart(buffer, boundary) {
    const parts = [];
    const boundaryBuffer = Buffer.from('--' + boundary);
    let start = 0;
    
    while (start < buffer.length) {
        const idx = buffer.indexOf(boundaryBuffer, start);
        if (idx === -1) break;
        
        const partStart = idx + boundaryBuffer.length;
        const nextBoundary = buffer.indexOf(boundaryBuffer, partStart);
        if (nextBoundary === -1) break;
        
        const partData = buffer.slice(partStart, nextBoundary - 2);
        start = nextBoundary;
        
        const headerEnd = partData.indexOf('\r\n\r\n');
        if (headerEnd === -1) continue;
        
        const headers = partData.slice(0, headerEnd).toString();
        const body = partData.slice(headerEnd + 4);
        
        const contentDisposition = headers.match(/Content-Disposition: form-data; name="(.+?)"/);
        const filenameMatch = headers.match(/filename="(.+?)"/);
        
        if (contentDisposition) {
            const fieldName = contentDisposition[1];
            if (filenameMatch) {
                parts.push({
                    fieldName,
                    filename: filenameMatch[1],
                    data: body
                });
            } else {
                parts.push({
                    fieldName,
                    value: body.toString()
                });
            }
        }
    }
    
    return parts;
}

const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    console.log('REQUEST:', req.method, req.url);
    
    // Serve static files
    if (req.method === 'GET' && !url.pathname.startsWith('/api')) {
        let filePath = url.pathname === '/' ? '/index.html' : url.pathname;
        filePath = path.join(__dirname, filePath);
        
        // Security: prevent directory traversal
        if (!filePath.startsWith(__dirname)) {
            res.writeHead(403);
            res.end('Forbidden');
            return;
        }
        
        const ext = path.extname(filePath);
        const contentType = mimeTypes[ext] || 'application/octet-stream';
        
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/plain' });
                res.end('Not Found');
                return;
            }
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
        });
        return;
    }
    
    // API: Upload from mobile
    if (req.method === 'POST' && url.pathname === '/api/upload') {
        let body = [];
        req.on('data', chunk => body.push(chunk));
        req.on('end', () => {
            const buffer = Buffer.concat(body);
            const contentType = req.headers['content-type'] || '';
            const boundary = contentType.split('boundary=')[1];
            
            if (!boundary) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'No boundary' }));
                return;
            }
            
            const parts = parseMultipart(buffer, boundary);
            const newImages = [];
            
            for (const part of parts) {
                if (part.filename && part.data.length > 0) {
                    const ext = path.extname(part.filename).toLowerCase();
                    const id = Date.now() + Math.random();
                    const filename = id + ext;
                    const filepath = path.join(UPLOADS_DIR, filename);
                    
                    fs.writeFileSync(filepath, part.data);
                    
                    const imageData = {
                        id,
                        filename,
                        original: `/uploads/${filename}`,
                        name: part.filename,
                        timestamp: Date.now()
                    };
                    newImages.push(imageData);
                    uploadedImages.push(imageData);
                    console.log('Saved image:', filename);
                }
            }
            
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, count: newImages.length }));
        });
        return;
    }
    
    // API: Poll for new images (desktop)
    if (req.method === 'GET' && url.pathname === '/api/images') {
        const since = parseInt(url.searchParams.get('since') || '0');
        const newImages = uploadedImages.filter(img => img.timestamp > since);
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            images: newImages,
            serverTime: Date.now()
        }));
        return;
    }
    
    // Serve uploaded files
    if (url.pathname.startsWith('/uploads/')) {
        const filename = url.pathname.slice(1);
        const filepath = path.join(__dirname, filename);
        
        if (!filepath.startsWith(UPLOADS_DIR)) {
            res.writeHead(403);
            res.end('Forbidden');
            return;
        }
        
        fs.readFile(filepath, (err, data) => {
            if (err) {
                res.writeHead(404);
                res.end('Not Found');
                return;
            }
            res.writeHead(200, { 'Content-Type': 'image/jpeg' });
            res.end(data);
        });
        return;
    }
    
    // 404
    res.writeHead(404);
    res.end();
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}/`);
    console.log('Open this URL in your browser');
});
